function [] = newton_eval_plot()
X = 0:0.01:1;
N= [200, 1000];
for i = 1:length(N)
    func = newton_eval(N(i));
    Y = subs(func, X);
    plot(X, Y);
    hold on;
end;

