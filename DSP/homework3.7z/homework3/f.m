function [y] = f(x)
if x